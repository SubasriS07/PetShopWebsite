var express=require('express');
var app=express();
const path = require('path');
//app.use(express.static(path.join(__dirname, '/public')));
const {MongoClient} = require("mongodb");
const url="mongodb://localhost:27017/";
const client=new MongoClient(url);
app.use(express.urlencoded({ extended: true }));
async function connect(){
	try{
		await client.connect();
		console.log('MongoDB Connected');
	}
	catch(err)
	{
		console.log('err occ');
		process.exit(1);
	}
}
app.use(express.static('/path/to/content'));
app.use('/public/images/',express.static('./public/images'));
app.use('/public/css/',express.static('./public/css'));
app.get('/',function(req,res){
    res.sendFile(__dirname+"/home.html");

});


app.get('/register',async function(req,res){
	
	var doc={name:req.query.username,email:req.query.email,gender:req.query.gender,password:req.query.password,city:req.query.city,phone_number:req.query.phone_number,dob:req.query.date_of_birth};
	const db=client.db("petstore");
	const coll=db.collection("users");
	var result=await coll.insertOne(doc);
	res.redirect("/login.html");
	res.end();
});

app.get('/home.html',function(req,res){
    res.sendFile(__dirname+"/home.html");

});
app.get('/admin.html',function(req,res){
    res.sendFile(__dirname+"/admin.html");

});
app.get("/login", async function (req, res) {
	var doc = {
	  name: req.query.username,
	  password: req.query.password,
	};
	const db=client.db("petstore");
	const coll=db.collection("users");
	const col1=db.collection("admin");
	var result = await col1.findOne(doc);
	//console.log(result);
	if (result != null ) {
	  //console.log("Logged In Successfully");
	  res.sendFile(__dirname + "/admin.html");
	} 
	else {
		var resul = await coll.findOne(doc);
		if(resul != null)
		{
			res.sendFile(__dirname + "/home.html");
		}	
		else{
			
	  		res.sendFile(__dirname + "/login.html");
		}
	}
  });
app.get('/update',async function(req,res){
	
	var doc={name:req.query.username,email:req.query.email};
	var newdoc={password:req.query.password};
	
	const db=client.db("petstore");
	const coll=db.collection("users");
	
	var result=await coll.updateOne(doc,{$set:newdoc});
	//res.write("<h1>Updated Ok</h1>");
	res.redirect("/login.html");
	res.end();
});

app.get('/delete',async function(req,res){
	
	var doc={name:req.query.username};
	const db=client.db("petstore");
	const coll=db.collection("users");
	var result=await coll.deleteOne(doc);
	res.redirect("/admin.html");
	res.end();
});
app.get('/findAll',async function(req,res){
	
	const db=client.db("petstore");
	const coll=db.collection("users");
	var result=await coll.find({},{_id:0,name:1,email:1}).toArray();
	res.write("<table border=1>")
	for(var i=0;i<result.length;i++)
	{
		res.write("<tr>");
		res.write("<td>"+result[i].name+"</td>");
		res.write("<td>"+result[i].email+"</td>");
		res.write("<td>"+result[i].gender+"</td>");
		res.write("<td>"+result[i].city+"</td>");
		res.write("<td>"+result[i].phone_number+"</td>");
		res.write("<td>"+result[i].dob+"</td>");
		res.write("</tr>");
	}
	res.write("</table>"); 
	res.write("<h2>||<a href='admin.html'>Back</a>||</h2>")
	res.end();
});
app.get('/findOne',async function(req,res){
	var doc={name:req.query.username};
	const db=client.db("petstore");
	const coll=db.collection("users");
	var result=await coll.find(doc).toArray();
	res.write("<table>")
	for(var i=0;i<result.length;i++)
	{
		res.write("<tr>");
		res.write("<td>"+result[i].name+"</td>");
		res.write("<td>"+result[i].email+"</td>");
		res.write("<td>"+result[i].gender+"</td>");
		res.write("<td>"+result[i].city+"</td>");
		res.write("<td>"+result[i].phone_number+"</td>");
		res.write("<td>"+result[i].dob+"</td>");
		//res.write(result[i].name+"            "+result[i].email+"            "+result[i].gender+"              "+result[i].city+"                "+result[i].phone_number+"                 "+result[i].dob);
		res.write("</tr>");
	}
	res.write("</table>"); 
	res.write("<h2>||<a href='admin.html'>Back</a>||</h2>")		
	res.end();
});

app.get('/login.html',function(req,res){
    res.sendFile(__dirname+"/login.html");

});
app.get('/forgetpwd.html',function(req,res){
    res.sendFile(__dirname+"/forgetpwd.html");

});
app.get('/register.html',function(req,res){
    res.sendFile(__dirname+"/register.html");

});
app.get('/feedback.html',function(req,res){
    res.sendFile(__dirname+"/feedback.html");

});
app.get('/contact.html',function(req,res){
    res.sendFile(__dirname+"/contact.html");

});
app.get('/selection.html',function(req,res){
    res.sendFile(__dirname+"/selection.html");

});
app.get('/select.html',function(req,res){
    res.sendFile(__dirname+"/select.html");

});
app.get('/catpd.html',function(req,res){
    res.sendFile(__dirname+"/catpd.html");

});
app.get('/checkoutbill.html',function(req,res){
    res.sendFile(__dirname+"/checkoutbill.html");

});
app.get('/fishContent.html',function(req,res){
    res.sendFile(__dirname+"/fishContent.html");

});
app.get('/birdContent.html',function(req,res){
    res.sendFile(__dirname+"/birdContent.html");

});
app.get('/sp2.html',function(req,res){
    res.sendFile(__dirname+"/sp2.html");

});
app.get('/sp3.html',function(req,res){
    res.sendFile(__dirname+"/sp3.html");

});
app.get('/sp4.html',function(req,res){
    res.sendFile(__dirname+"/sp4.html");

});

app.listen(5000, () => {
    console.log('Server is running on port 5000');
	connect();
  });